import random

from controllers.ControllerActorWarrior import ControllerActorWarrior
from controllers.interfaces.IControllerActor import IControllerActor


class ControllerActorRider(ControllerActorWarrior):
    pass