import random
from views.WindowMain import WindowMain

random.seed(1)
windowMain = WindowMain()
windowMain.show()